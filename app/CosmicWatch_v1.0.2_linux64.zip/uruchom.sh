#!/bin/bash
java -Djava.library.path=. -jar CosmicWatchApp.jar
